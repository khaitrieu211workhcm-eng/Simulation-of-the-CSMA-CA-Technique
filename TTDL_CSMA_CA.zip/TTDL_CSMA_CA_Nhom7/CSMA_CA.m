% CHUONG TRINH MO PHONG CSMA/CA

clear; clc; close all;

% 1. KHOI TAO CAC THAM SO HE THONG
Payload_size = 10000;                 % Payload (Bytes)
Data_rate = 6e6;                     % Data_rate (bps)
T = 1;                               % Thoi gian mo phong (s)
N_max = 200;                         % So luong tram toi da

% CAC HANG SO IEEE 802.11
Slot_time = 9e-6;
DIFS = 34e-6;
SIFS = 16e-6;
ACK_size = 14 * 8;                   % bits
MAC_Header = 34 * 8;                 % bits
Payload_bits = Payload_size * 8;     % bits

% THOI GIAN TRUYEN
T_packet = (Payload_bits + MAC_Header) / Data_rate;
T_ACK = ACK_size / Data_rate;

T_success = DIFS + T_packet + SIFS + T_ACK;
T_collision = DIFS + T_packet;

% CW
CW_min = 15;
CW_max = 1023;

% LUU KET QUA
U = zeros(N_max, 5);

% 2. MO PHONG
for Backoff_St = 1:5
    for N = 1:N_max
        
        good_time = 0;
        total_time = 0;
        
        CW = ones(N,1) * CW_min;
        
        % backoff random
        r = randi([0, CW_min], N, 1) * Slot_time;
        
        while total_time < T
            
            min_r = min(r);
            idx = find(r == min_r);
            count = length(idx);
            
            total_time = total_time + min_r;
            
            if count == 1
                % SUCCESS
                good_time = good_time + (Payload_bits / Data_rate);
                total_time = total_time + T_success;
                
                CW_curr = CW(idx);
                
                switch Backoff_St
                    case 1
                        CW(idx) = CW_min;
                    case 2
                        CW(idx) = max(CW_min, round(CW_curr / 2));
                    case 3
                        CW(idx) = max(CW_min, round(CW_curr / 2));
                    case 4
                        CW(idx) = max(CW_min, CW_curr - CW_min);
                    case 5
                        CW(idx) = max(CW_min, CW_curr - CW_min);
                end
                
                r(idx) = randi([0, CW(idx)]) * Slot_time;
                
            else
                % COLLISION
                total_time = total_time + T_collision;
                
                for k = 1:count
                    node_id = idx(k);
                    CW_curr = CW(node_id);
                    
                    switch Backoff_St
                        case 1
                            CW(node_id) = min(CW_max, CW_curr * 2);
                        case 2
                            CW(node_id) = min(CW_max, CW_curr + CW_min);
                        case 3
                            CW(node_id) = min(CW_max, CW_curr * 2);
                        case 4
                            CW(node_id) = min(CW_max, CW_curr + CW_min);
                        case 5
                            CW(node_id) = min(CW_max, CW_curr * 2);
                    end
                    
                    r(node_id) = randi([0, CW(node_id)]) * Slot_time;
                end
            end
            
            % FROZEN BACKOFF
            non_idx = true(N,1);
            non_idx(idx) = false;
            r(non_idx) = r(non_idx) - min_r;
        end
        
        % UTILIZATION
        U(N, Backoff_St) = good_time / total_time;
    end
end

% 3. VE DO THI
figure;
plot(1:N_max, U(:,1),'b','LineWidth',1.5); hold on;
plot(1:N_max, U(:,2),'r','LineWidth',1.5);
plot(1:N_max, U(:,3),'y','LineWidth',1.5);
plot(1:N_max, U(:,4),'m','LineWidth',1.5);
plot(1:N_max, U(:,5),'g','LineWidth',1.5);

title(sprintf('CSMA/CA (Payload = %d Bytes)', Payload_size));
xlabel('Number of Nodes (N)');
ylabel('Utilization (U)');
legend('802.11','AIMD','MIMD','AIAD','MIAD');
grid on;